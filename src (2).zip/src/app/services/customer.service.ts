// services/customer.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  private apiUrl = '/api/administrator/getAllCustomers';

  constructor(private http: HttpClient) { }

  getAllCustomers(): Observable<any> {
    return this.http.get<{ data: any[] }>(this.apiUrl).pipe(
      map(response => response.data), // Extract the data property
      catchError(error => {
        console.error('API Error:', error);
        throw 'Failed to load customers, check console';
      })
    );
  }
}