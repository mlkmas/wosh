import { Component } from '@angular/core';

@Component({
  selector: 'app-reservations',
  imports: [],
  templateUrl: './reservations.component.html',
  styleUrl: './reservations.component.css'
})
export class ReservationsComponent {

}
